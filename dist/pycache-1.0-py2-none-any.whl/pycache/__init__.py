from cache import Cache, Flask_Cache
from mechanism import mechanism, redis_cache, simple_cache
